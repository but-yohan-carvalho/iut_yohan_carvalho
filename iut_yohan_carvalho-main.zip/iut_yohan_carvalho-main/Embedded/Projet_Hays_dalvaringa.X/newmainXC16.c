/*
 * File:   newmainXC16.c
 * Author: TP-EO-1
 *
 * Created on 21 septembre 2022, 14:53
 */


#include "xc.h"

int main(void) {
    return 0;
}
