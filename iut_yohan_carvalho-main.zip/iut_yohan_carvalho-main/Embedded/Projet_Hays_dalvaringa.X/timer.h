#ifndef TIMER_H
#define TIMER_H
void InitTimer23 ( void ) ;
void InitTimer1 ( void ) ;
#endif /*TIMER_H*/
